﻿using UnityEngine;
using System.Collections;

public  class DataFile  {

	public static float width 	= /* 1.74758f;//*/1.415f;//1.67f;//1.73f;
	public static float height 	= /*1.413087f;//*/1.14705f;//1.14755f;//1.35f;//1.36f;-3.7975
	
	public static float min = 2.0f;
	public static float sec = 30f;

	public static int 	rows	= 09;
	public static int	cols	= 15;//12;
	
	public static Vector3 statingPos = new Vector3 /*( -10.02f,-4.673f,0f);//*/(-10.02f,-4.94455f,0f);//Vector3(-9.645f,-4.94455f,0f);// Vector3(-9.5f,-4.839f,0f);
	
	public static float CorealSpeed = 450f;
	
	public static	int snailscore		=	550;
	public static	int crabscore		=	750;
	public static	int shrimpscore 		=	750;
	public static	int octupusScore		=	850;
	public static	int fishScore		=	850;
	public static	int clamScore  		=   1000;
	public static	int starFishScore	=	1000;
	public static	int eelScore			=	2000;
	public static	int oystersScore		=	150;
}
